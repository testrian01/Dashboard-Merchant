<?php

$conf['dbhostmaster_1'] = '127.0.0.1';
$conf['dbusermaster_1'] = 'user_1';
$conf['dbpassmaster_1'] = 'sGd2412@$';
$conf['dbtypemaster_1'] = 'mysqli';
$conf['dbnamemaster_1'] = '';

$conf['dbhostslave1_1'] = '127.0.0.1';
$conf['dbuserslave1_1'] = 'user_1';
$conf['dbpassslave1_1'] = 'sGd2412@$';
$conf['dbtypeslave1_1'] = 'mysqli';
$conf['dbnameslave1_1'] = '';

$conf['dbhostslave2_1'] = '127.0.0.1';
$conf['dbuserslave2_1'] = 'user_1';
$conf['dbpassslave2_1'] = 'sGd2412@$';
$conf['dbtypeslave2_1'] = 'mysqli';
$conf['dbnameslave2_1'] = '';