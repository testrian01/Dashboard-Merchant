<?php

$config['rabbitmq_host'] = '192.168.200.8';
$config['rabbitmq_port'] = 5672;
$config['rabbitmq_user'] = 'root';
$config['rabbitmq_password'] = '';
$config['rabbitmq_vhost'] = '/';