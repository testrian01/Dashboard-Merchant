<?php

$holidaySettle = array('Sat','Sun');

$whitelistIp = array('110.239.84.14','192.168.200.1','192.168.200.2','192.168.200.5','192.168.200.6','192.168.200.7','192.168.0.1','158.220.72.41','202.53.225.142','202.10.36.42');

$stateProgram = 'Development';

$internalUrlHit = 'https://stagginggatewayinternal.gidi.co.id';
$externalUrlHit = 'https://stagginggatewayexternal.gidi.co.id';

$ifpIpCallback = array('110.239.84.14','34.101.221.242','202.10.36.42');

$ifpUrlHit = 'https://api-stage.mcpayment.id';
$ifpMerchantId = 'MCP2024022788';
$ifpSecretUnboundId = '';
$ifpHasKey = '';

$ifpDefaultPaymentChannel = 'SHOPEEPAY';
$ifpDefaultCurrency       = 'IDR';
$ifpDefaultPaymentMethod  = 'wallet';


$senmoUrlHit = 'https://api-stage.senmo.id';
$senmoCredentialId = 'MCPD2402150083';
$senmoCredentialSecret = '24e9e644c4adeae9';
$senmoGidAccountNo = '5050177400';

$gvconnectUrlHit = 'https://devopenapi.gudangvoucher.com/gv_connect';

$gvconnectClientId = 'a3066aeabc26d0a9cffbf542c1d2daa1';
$gvconnectClientKey = '';

$gvconnectMerchantId = '1204';
$gvconnectMerchantKey = '0bc7ef5b726acde3f6febe49';

$gvPayUrlHit = 'https://devopenapi.gudangvoucher.com/pg';
$gvPayMerchantId = '1214';
$gvPayMerchantKey = '';

$gvconnectIpCallback = array('110.239.84.14','117.54.7.214','202.10.36.42');

$gvconnectDisbursementAccountKey = 'GV4524283001726679596';
$gvconnectDisbursementAccountUsername = 'test_1726679596';

$conf['dbhostmaster'] = 'host.docker.internal';
$conf['dbusermaster'] = 'user_1';
$conf['dbpassmaster'] = '';
$conf['dbtypemaster'] = 'mysqli';
$conf['dbnamemaster'] = '';

$conf['dbhostslave1'] = 'host.docker.internal';
$conf['dbuserslave1'] = 'user_1';
$conf['dbpassslave1'] = '';
$conf['dbptypelave1'] = 'mysqli';
$conf['dbnameslave1'] = '';

$conf['dbhostslave2'] = 'host.docker.internal';
$conf['dbuserslave2'] = 'user_1';
$conf['dbpassslave2'] = '';
$conf['dbtypelave2'] = 'mysqli';
$conf['dbnameslave2'] = '';