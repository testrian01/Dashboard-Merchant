<script>
    function resetForm() {
        document.getElementById("search_date").value = "";
        document.getElementById("search_submerchant").value = "";
        document.getElementById("search_position").value = "";

        return false;
    }
</script>